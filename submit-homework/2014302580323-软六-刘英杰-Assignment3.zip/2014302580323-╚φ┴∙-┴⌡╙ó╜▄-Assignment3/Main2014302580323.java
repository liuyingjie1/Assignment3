/**
 * 
 */
package info;

import java.sql.DriverManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * @author Administrator
 *
 */
public class Main2014302580323 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread1 thread1=new Thread1();
		Thread2 thread2=new Thread2();
		Thread3 thread3=new Thread3();
		Thread4 thread4=new Thread4();
		Thread5 thread5=new Thread5();
		Thread6 thread6=new Thread6();
		Thread7 thread7=new Thread7();
		Thread8 thread8=new Thread8();
		Thread9 thread9=new Thread9();
		Thread10 thread10=new Thread10();
		thread1.start();
		thread2.start();
		thread3.start();
		thread4.start();
		thread5.start();
		thread6.start();
		thread7.start();
		thread8.start();
		thread9.start();
		thread10.start();
		System.out.print("�����ɹ�");
	}
	

}
class Thread1 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635485419965156182&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread2 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635495171081406023&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread3 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635467370562500025&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread4 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635623566637500043&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread5 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635467381653437034&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread6 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635485419963906151&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread7 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=859085390000000001&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread8 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635485419964531165&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread9 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635485419963906152&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
class Thread10 extends Thread
{
	public void run()
	{
		try {
			Document document=Jsoup.connect("http://hr.ustc.edu.cn/cn/shizi.aspx?infoid=635485419963906150&infotypeid=841300015156250016").get();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/professor?useUnicode=true&characterEncoding=gb2312","root","123456");
				Statement statement=(Statement) connection.createStatement();
				String name=document.getElementById("oTalentName").text().split(" ")[0];
				String introd=document.getElementById("oInfoDescB").text();
				String inter=document.getElementById("oInfoDescC").text();
				String telAndEma=document.getElementById("oInfoDescH").text();
				Pattern pattern=Pattern.compile("\\d{11}|(\\d{4}-\\d{8})");
				Matcher matcher=pattern.matcher(telAndEma);
				String phone="",email="";
				while(matcher.find())
				{	if(phone.isEmpty())
						phone=phone+matcher.group();
					else {
						phone=phone+";"+matcher.group();
					}
				}
				pattern=Pattern.compile("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)");
				matcher=pattern.matcher(telAndEma);
				while (matcher.find()) {
					if(email.isEmpty())
						email=email+matcher.group();
					else {
						email=email+";"+matcher.group();
					}
				}
				statement.execute("INSERT INTO professorinfo(��������,���ڱ���,�о���Ȥ,���ڵ绰,�����ʼ�) VALUES('"+name+"','"+introd+"','"+inter+"','"+phone+"','"+email+"')");
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
